import time
import os
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY  = os.getenv("RECALL_API_KEY")
BASE_URL = "https://api.sandbox.competitions.recall.network"

FROM_TOKEN = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"  # USDC
TO_TOKEN   = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # WETH
AMOUNT_USDC = "100"

def run_trade():
    payload = {
        "fromToken": FROM_TOKEN,
        "toToken":   TO_TOKEN,
        "amount":    AMOUNT_USDC,
        "reason":    "Auto loop trade"
    }

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type":  "application/json"
    }

    print("⏳ Sending trade…")
    resp = requests.post(f"{BASE_URL}/api/trade/execute", json=payload, headers=headers)

    if resp.ok:
        print("✅ Trade successful:", resp.json())
    else:
        print("❌ Trade failed:", resp.status_code, resp.text)

# 🌀 Loop every 0. minutes
while True:
    run_trade()
    print("⏸ Waiting 0.1 minutes before next trade...\n")
    time.sleep(6)  # 6 giây = 0.1 phút

